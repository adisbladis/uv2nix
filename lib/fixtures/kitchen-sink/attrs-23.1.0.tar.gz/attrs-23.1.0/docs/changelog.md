```{include} ../CHANGELOG.md
:end-before: Changes for the upcoming release can be found
```

 ```{towncrier-draft-entries}
main
 ```

```{include} ../CHANGELOG.md
:start-after: towncrier release notes start -->
```
